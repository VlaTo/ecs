﻿namespace ClassLibrary3
{
    public interface IDataRow
    {
        int ReadInt32();

        string ReadString();

        long ReadInt64();
    }
}