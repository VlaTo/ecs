﻿namespace ClassLibrary3
{
    public interface IState
    {
    }
}